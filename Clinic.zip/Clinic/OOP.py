#note everything is lower caps for attributes and functions
#note in line 4, please write the database file trying to conenct
from sqlite3 import *
conn = connect("clinic.db")
#person class
class person:
    #attributes
    def __init__(self):
        self.__nric = ""
        self.__type = ""
        self.__first_name = ""
        self.__last_name = ""
        self.__date_of_birth = ""
        self.__gender = ""
        self.__clinic = None
        self.__home_address = ""
        self.__contact_number = -1
        self.__allergy = ""
        
    #get functions
    def getnric(self):
        return self.__nric
    def gettype(self):
        return self.__type
    def getfirst_name(self):
        return self.__first_name
    def getlast_name(self):
        return self.__last_name
    def getdate_of_birth(self):
        return self.__date_of_birth
    def getgender(self):
        return self.__gender
    def getclinic(self):
        return self.__clinic
    def gethome_address(self):
        return self.__home_address
    def getcontact_number(self):
        return self.__contact_number
    def getallergy(self):
        return self.__allergy
    
    #set functions
    def setnric(self,nric):
        self.__nric = nric
    def settype(self,type1):
        self.__type = type1
    def setfirst_name(self,first_name):
        self.__first_name = first_name
    def setlast_name(self,last_name):
        self.__last_name = last_name
    def setdate_of_birth(self,date_of_birth):
        self.__date_of_birth = date_of_birth
    def setgender(self,gender):
        self.__gender = gender
    def setclinic(self,clinic):
        self.__clinic = clinic
    def sethome_address(self,home_address):
        self.__home_address = home_address
    def setcontact_number(self,contact_number):
        self.__contact_number = contact_number
    def setallergy(self,allergy):
        self.__allergy = allergy
        
#patient class
class patient(person):
    def __init__(self):
        super().__init__()
        self.__type = "patient"
        
#staff class
class staff(person):
    def __init__(self):
        super().__init__()
        self.__status = ""
    def getstatus(self):
        return self.__status
    def setstatus(self,status):
        self.__status = status
        
#Clinic class
class clinic:
    def __init__(self):
        self.__clinic = ""
        self.__clinic_address = ""
        self.__clinic_contact = ""
    #get functions
    def getclinic(self):
        return self.__clinic
    def getclinic_address(self):
        return self.__clinic_address
    def getclinic_contact(self):
        return self.__clinic_contact

    #set functions
    def setclinic(self,clinic):
        self.__clinic = clinic
    def setclinic_address(self,clinic_address):
        self.__clinic_address = clinic_address
    def setclinic_contact(self,clinic_contact):
        self.__clinic_contact = clinic_contact
        
#helper functions


def obtaindata():
    global cliniclst,personlst,patientlst,stafflst
    cliniclst = []
    personlst = []
    patientlst = []
    stafflst = []
    
    for line in conn.execute("SELECT * FROM Clinic"):
        clinic1 = clinic()
        clinic1.setclinic(line[0])
        clinic1.setclinic_address(line[1])
        clinic1.setclinic_contact(line[2])
        cliniclst.append(clinic1)
    for line in conn.execute("SELECT * FROM Person"):
        person1 = person()
        person1.setnric(line[0])
        person1.settype(line[1])
        person1.setfirst_name(line[2])
        person1.setlast_name(line[3])
        person1.setdate_of_birth(line[4])
        person1.sethome_address(line[5])
        person1.setcontact_number(line[6])
        person1.setgender(line[7])
        person1.setallergy(line[8])
        personlst.append(person1)
    for line in conn.execute("SELECT * FROM Patient"):
        patient1 = patient()
        patient1.setnric(line[0])
        patient1.setclinic(line[1])
        patientlst.append(patient1)
    for line in conn.execute("SELECT * FROM Staff"):
        staff1 = staff()
        staff1.setnric(line[0])
        staff1.setclinic(line[1])
        staff1.setstatus(line[2])
        
def searchperson(nric): # if empty returns None
    lst = []
    lst4 = []
    lst5 = []
    person1 = conn.execute("SELECT * FROM Person WHERE Person.nric LIKE (?)",(nric,))
    person2 = conn.execute("SELECT clinic,status FROM Staff WHERE Staff.nric = (?)",(nric,))
    for line in person2:
        lst4.append(line)
    for line in person1:
        lst.append(line)
    lst = list(lst[0])
    if len(lst4) == 2:
        a = lst
        lst.append(lst4[0][0])
        lst.append(lst4[0][1])
        a.append(lst4[1][0])
        a.append(lst4[1][1])
        return lst, a
    if len(lst4 == 3):
        b = lst
        lst.append(lst4[0][0])
        lst.append(lst4[0][1])
        a.append(lst4[1][0])
        a.append(lst4[1][1])
        b.append(lst4[2][0])
        b.append(lst4[2][1])
        return lst, a
    else:
        lst.append(lst4[0][0])
        lst.append(lst4[0][1])
    if lst == []:
        return None
    else:   
        return lst
        
def insertperson(nric,type1,first_name,last_name,date_of_birth,gender,clinic1,home_address,contact_number,allergy,status):
    lst2 = []
    value = conn.execute("SELECT nric FROM Person WHERE Person.nric = (?)",(nric,))
    if value != []:
        conn.execute("INSERT INTO Person(nric,type,f_name,l_name,dob,home_addr,contact,gender,allergy)" +
                 "VALUES(?,?,?,?,?,?,?,?,?)",(nric,type1,first_name,last_name,date_of_birth,gender,home_address,contact_number,allergy))
    if type1 == "patient":
        conn.execute("INSERT INTO PATIENT(nric,clinic) VALUES(?,?)",(nric,clinic1))
    else:
        conn.execute("INSERT INTO STAFF(nric,clinic,status) VALUIES(?,?,?)",(nric,clinic,status))
    conn.commit()
    #if the patient alrdy in persons list, then it only adds to patient
    #but if patient not in person lst, it add to both patient and person
    #function only for patient not for staff yet
def displayclinic(clinic):
    lstofclinic = []
    lstofnric = []
    lstofperson = []
    specific_nric = None
    specific_clinic = conn.execute("SELECT nric FROM Patient WHERE Patient.clinic = (?)",(clinic,))
    for index in specific_clinic:
        lstofclinic.append(index)
    for index in range(len(lstofclinic)):
        line = lstofclinic[index][0]
        specific_nric = conn.execute("SELECT * FROM Person WHERE Person.nric = (?)",(line,))
        lstofperson = []
        for line in specific_nric:
            lstofperson.append(line)
        lstofnric.append(lstofperson)
    return lstofnric
    #returns the lst of patients that belong to a specific clinic

def countpaitents(clinic):
    obtaindata()
    count = 0
    for line in patientlst:
        if line.getclinic() == str(clinic):
            count += 1
    return count

def updateperson(nric,type1,first_name,last_name,date_of_birth,gender,clinic1,home_address,contact_number,allergy):
    lst3 = []
    value = conn.execute("SELECT nric FROM Person WHERE Person.nric = (?)",(nric,))
    for line in value:
        lst3.append(line)
    if lst3[0][0] == []:
        return False
    else:
        conn.execute("UPDATE Person SET type = (?), f_name = (?), l_name = (?), dob = (?), home_addr = (?), contact = (?), gender = (?), allergy = (?) WHERE Person.nric = (?)",(type1,first_name,last_name,date_of_birth,gender,home_address,contact_number,allergy,nric))
        conn.commit()
        return True
    
def updatestatus(nric,clinic,status):
    conn.execute("UPDATE Staff SET status = (?) WHERE Staff.nric = (?) and Staff.clinic = (?)", (status,nric,clinic))
    conn.commit()

    
    
#____________________main programm ________________________________________
#testcases

obtaindata() #this gets the data into the lst

#for index in cliniclst:
#    print(index.getclinic(),index.getclinic_address(),index.getclinic_contact())
#print("")
#for index in patientlst:
#    print(index.getnric(),index.getclinic())
#for index in personlst:
#    print(index.getnric(),index.gettype(),index.getfirst_name(),index.getlast_name(),index.getdate_of_birth(),index.gethome_address(),index.getcontact_number(),index.getgender(),index.getallergy())
#print(searchperson("S1511890S"))
#print(searchperson("test_if_not_in_place_should_return_None"))
#insertperson("t01234567A","patient","lim","james","3/8/2003","male","Bedok","Bedok St 21","61234455","None",None) #note i dont know how to delete james once inserted
#for line in displayclinic("Bedok"):
#    print(line)
#print(countpaitents("Bedok"))
#print(countpaitents("Jurong"))
#print(countpaitents("Clementi"))
#print(countpaitents("Bishan"))
#print(countpaitents("Yishun"))
#print(searchperson("S9633029Q"))
#updateperson("S9633029Q","receptionist","Karney","Potteril","29/6/1950","Male","Jurong","Jurong East Central","62233538","testforupdate")
#print(searchperson("S9633029Q"))
#print(searchperson("S3773926C"))
#updatestatus("S9633029Q","Jurong","active")
#print(searchperson("S9633029Q"))
#print(searchperson("S0903821B"))

#post main programm
conn.close()
