from flask import *
from sqlite3 import *
app = Flask(__name__)

#retrieve all information from a clinic
def show(clinic):
    person_lst = []
    status_lst = []
    conn = connect("clinic.db")
    nric_staff = conn.execute("SELECT nric FROM Staff WHERE clinic = ?",(clinic,)).fetchall()
    nric_patient = conn.execute("SELECT nric FROM Patient WHERE clinic = ?",(clinic,)).fetchall()
    for x in range(len(nric_staff)):
        nric = nric_staff[x][0]
        person_x = conn.execute("SELECT * FROM Person where nric = ?",(nric,)).fetchone()
        person_lst.append(person_x)
        staff_x = conn.execute("SELECT status FROM Staff where nric = ?",(nric,)).fetchone()
        status_lst.append(staff_x)
    for y in range(len(nric_patient)):
        nric = nric_patient[y][0]
        person_y = conn.execute("SELECT * FROM Person where nric = ?",(nric,)).fetchone()
        person_lst.append(person_y)
    conn.close()
    return person_lst, status_lst

#check if a particular exists in database
def search_exist(value):
    conn = connect("clinic.db")
    lst = conn.execute("SELECT * FROM Person WHERE nric = ?",(value,)).fetchone()
    conn.close()
    if lst == None:
        return False
    else:
        return True

#index page
@app.route("/")
def main():
    #get patient count from database
    conn = connect("clinic.db")
    bedok_count = conn.execute("SELECT COUNT(nric) FROM Patient WHERE clinic = 'Bedok'").fetchone()[0]
    bishan_count = conn.execute("SELECT COUNT(nric) FROM Patient WHERE clinic = 'Bishan'").fetchone()[0]
    clementi_count = conn.execute("SELECT COUNT(nric) FROM Patient WHERE clinic = 'Clementi'").fetchone()[0]
    jurong_count = conn.execute("SELECT COUNT(nric) FROM Patient WHERE clinic = 'Jurong'").fetchone()[0]
    yishun_count = conn.execute("SELECT COUNT(nric) FROM Patient WHERE clinic = 'Yishun'").fetchone()[0]
    conn.close()
    return render_template("index.html", bedok_count = bedok_count, bishan_count = bishan_count, clementi_count = clementi_count, jurong_count = jurong_count, yishun_count = yishun_count)

#back to index page
@app.route("/index")
def index():
    return main()

#display batabase of each clinic
@app.route("/bedok")
def bedok():
    lst1, lst2 = show("Bedok")
    lst2 += [("",)] * (len(lst1)-len(lst2))
    return render_template("bedok.html", lst1 = lst1, lst2 = lst2, count = len(lst1))

@app.route("/bishan")
def bishan():
    lst1, lst2 = show("Bishan")
    lst2 += [("",)] * (len(lst1)-len(lst2))
    return render_template("bishan.html", lst1 = lst1, lst2 = lst2, count = len(lst1))

@app.route("/clementi")
def clementi():
    lst1, lst2 = show("Clementi")
    lst2 += [("",)] * (len(lst1)-len(lst2))
    return render_template("clementi.html", lst1 = lst1, lst2 = lst2, count = len(lst1))

@app.route("/jurong")
def jurong():
    lst1, lst2 = show("Jurong")
    lst2 += [("",)] * (len(lst1)-len(lst2))
    return render_template("jurong.html", lst1 = lst1, lst2 = lst2, count = len(lst1))

@app.route("/yishun")
def yishun():
    lst1, lst2 = show("Yishun")
    lst2 += [("",)] * (len(lst1)-len(lst2))
    return render_template("yishun.html", lst1 = lst1, lst2 = lst2, count = len(lst1))

#proceed to add new particular
@app.route("/add_staff")
def add_staff():
    return render_template("addstaff.html", nric = False)

@app.route("/add_patient")
def add_patient():
    return render_template("addpatient.html", nric = False)

@app.route("/redirect_add_staff", methods=["POST"])
def redirect_add_staff():
    data = request.form
    value = str(data["value"])
    return render_template("addstaff.html", nric = value)

@app.route("/refirect_add_patient", methods=["POST"])
def redirect_add_patient():
    data = request.form
    value = str(data["value"])
    return render_template("addpatient.html", nric = value)

#show search output
@app.route("/search", methods=["POST"])
def search():
    conn = connect("clinic.db")
    data = request.form
    value = str(data["value"])
    #search for particular in the database
    lst = conn.execute("SELECT * FROM Person WHERE nric = ?",(value,)).fetchone()
    #check whether particular exists in the databse
    if lst == None:
        conn.close()
        return render_template("none.html", nric = value)
    else:
        if lst[1] == "patient":
            cursor = conn.execute("SELECT clinic FROM Patient WHERE nric = ?",(value,)).fetchall()
            lst_clinic = []
            lst_status = None
            for item in cursor:
                lst_clinic.append(item[0])
        else:
            cursor = conn.execute("SELECT clinic, status FROM Staff WHERE nric = ?",(value,)).fetchall()
            lst_clinic = []
            lst_status = []
            for item in cursor:
                lst_clinic.append(item[0])
                lst_status.append(item[1])
        conn.close()
        return render_template("search.html", lst = lst, lst_clinic = lst_clinic, lst_status = lst_status, nric = value, type = lst[1], clinic_no = len(lst_clinic))

#proceed to edit existing Particular
@app.route("/edit_staff", methods=["POST"])
def edit_staff():
    conn = connect("clinic.db")
    data = request.form
    value = str(data["value"])
    lst = conn.execute("SELECT * FROM Person WHERE nric = ?",(value,)).fetchone()
    cursor = conn.execute("SELECT clinic, status FROM Staff WHERE nric = ?",(value,)).fetchall()
    lst_clinic = []
    lst_status = []
    for item in cursor:
        lst_clinic.append(item[0])
        lst_status.append(item[1])
    conn.close()
    return render_template("editstaff.html", lst = lst, lst_clinic = lst_clinic, lst_status = lst_status, clinic_no = len(lst_clinic))

@app.route("/edit_patient", methods=["POST"])
def edit_patient():
    conn = connect("clinic.db")
    data = request.form
    value = str(data["value"])
    lst = conn.execute("SELECT * FROM Person WHERE nric = ?",(value,)).fetchone()
    cursor = conn.execute("SELECT clinic FROM Patient WHERE nric = ?",(value,)).fetchall()
    lst_clinic = []
    lst_status = None
    for item in cursor:
        lst_clinic.append(item[0])
    conn.close()
    return render_template("editpatient.html", lst = lst, lst_clinic = lst_clinic, clinic_no = len(lst_clinic))

#show save successful
@app.route("/save", methods=["POST"])
def save():
    conn = connect("clinic.db")
    data = request.form
    type = str(data["new_type"])
    nric = str(data["new_nric"])
    fname = str(data["new_fname"])
    lname = str(data["new_lname"])
    dob = str(data["new_dob"])
    addr = str(data["new_addr"])
    contact = str(data["new_contact"])
    gender = str(data["new_gender"])
    clinic = str(data["new_clinic"])
    if search_exist(nric) == False:
        if type == "patient":
            allergy = str(data["new_allergy"])
            conn.execute("INSERT INTO Person VALUES(?,?,?,?,?,?,?,?,?)", (nric, type, fname, lname, dob, addr, contact, gender, allergy))
            conn.execute("INSERT INTO Patient VALUES(?,?)", (nric, clinic))
            conn.commit()
        else:
            allergy = ""
            status = str(data["new_status"])
            conn.execute("INSERT INTO Person VALUES(?,?,?,?,?,?,?,?,?)", (nric, type, fname, lname, dob, addr, contact, gender, allergy))
            conn.execute("INSERT INTO Staff VALUES(?,?,?)", (nric, clinic, status))
            conn.commit()
    else:
        if type == "patient":
            conn.execute("INSERT INTO Patient VALUES(?,?)", (nric, clinic))
            conn.commit()
        else:
            status = str(data["new_status"])
            conn.execute("INSERT INTO Staff VALUES(?,?,?)", (nric, clinic, status))
            conn.commit()
    conn.commit()
    conn.close()
    return render_template("save.html")

#show update successful
@app.route("/update", methods=["POST"])
def update():
    conn = connect("clinic.db")
    data = request.form
    type = str(data["new_type"])
    nric = str(data["new_nric"])
    fname = str(data["new_fname"])
    lname = str(data["new_lname"])
    dob = str(data["new_dob"])
    addr = str(data["new_addr"])
    contact = str(data["new_contact"])
    clinic = str(data["new_clinic"])
    if type == "patient":
        allergy = str(data["new_allergy"])
        conn.execute("UPDATE Person SET f_name=(?), l_name=(?), dob=(?), home_addr=(?), contact=(?), allergy=(?) WHERE nric=(?)", (fname, lname, dob, addr, contact, allergy, nric))
        conn.commit()
    else:
        status = str(data["new_status"])
        conn.execute("UPDATE Person SET f_name=(?), l_name=(?), dob=(?), home_addr=(?), contact=(?) WHERE nric=(?)", (fname, lname, dob, addr, contact, nric))
        conn.execute("UPDATE Staff SET status=(?) WHERE nric=(?) AND clinic=(?)", (status, nric, clinic))
        conn.commit()
    conn.commit()
    conn.close()
    return render_template("update.html")

if __name__ == "__main__":
    app.run(port = 5600, debug = True)
