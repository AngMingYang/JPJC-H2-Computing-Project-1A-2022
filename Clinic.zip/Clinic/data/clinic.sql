CREATE TABLE Clinic(
    clinic TEXT,
    clinic_addr TEXT,
    clinic_contact TEXT,
    PRIMARY KEY(clinic)
);

CREATE TABLE Person(
    nric TEXT,
    type TEXT,
    f_name TEXT,
    l_name TEXT,
    dob TEXT,
    home_addr TEXT,
    contact TEXT,
    gender TEXT,
    allergy TEXT,
    PRIMARY KEY(nric)
);

CREATE TABLE Patient(
    nric TEXT,
    clinic TEXT,
    PRIMARY KEY(nric, clinic),
    FOREIGN KEY(nric) REFERENCES Person(nric),
    FOREIGN KEY(clinic) REFERENCES Clinic(clinic)
);

CREATE TABLE Staff(
    nric TEXT,
    clinic TEXT,
    status TEXT,
    PRIMARY KEY(nric, clinic),
    FOREIGN KEY(nric) REFERENCES Person(nric),
    FOREIGN KEY(clinic) REFERENCES Clinic(clinic)
);
