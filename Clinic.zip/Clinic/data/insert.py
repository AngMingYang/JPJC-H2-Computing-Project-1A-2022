import sqlite3
conn = sqlite3.connect("clinic.db")

file = open("CLINICS_DATA.csv","r")
header = file.readline()
clinic_lst = []
nric_lst = []
for line in file:
    line = line.strip()
    person_type,nric,first_name,last_name,date_of_birth,home_address,contact_number,gender,clinic,clinic_address,clinic_contact,allergy,status = line.split(",")
    if clinic not in clinic_lst:
        clinic_lst.append(clinic)
        conn.execute("INSERT INTO Clinic(clinic,clinic_addr,clinic_contact) VALUES(?,?,?)",(clinic,clinic_address,clinic_contact))
    if nric not in nric_lst:
        nric_lst.append(nric)
        conn.execute("INSERT INTO Person(nric,type,f_name,l_name,dob,home_addr,contact,gender,allergy) VALUES(?,?,?,?,?,?,?,?,?)",(nric,person_type,first_name,last_name,date_of_birth,home_address,contact_number,gender,allergy))
    if person_type == "patient":
        conn.execute("INSERT INTO Patient(nric,clinic) VALUES(?,?)",(nric,clinic))
    else:
        conn.execute("INSERT INTO Staff(nric,clinic,status) VALUES(?,?,?)",(nric,clinic,status))
    conn.commit()

file.close()
conn.close()
